#pragma once

void displayinfo();
void displaygpio();
int format(int mode);
int dumpfirmware();